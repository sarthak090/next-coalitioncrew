export default {
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://ccrewnft.com",
    site_name: "Coalitioncrew",
  },
};
