export default {
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://coalitioncrew.com",
    site_name: "Coalitioncrew",
  },
};
